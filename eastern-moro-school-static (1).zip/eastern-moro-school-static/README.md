# Eastern Moro Islamic English Medium School — Static Website

A responsive static website built with HTML, CSS and vanilla JavaScript. It does not require PHP, a database, or an admin panel.

## Pages
- `index.html` — Home
- `about.html` — About the school
- `academics.html` — Academic programmes
- `admissions.html` — Admission enquiry
- `application-status.html` — Application information (informational only; no application database)
- `gallery.html` — Gallery
- `news.html` — News and announcements
- `contact.html` — Contact
- `404.html` — Not found page

## Visual features
- Responsive layout and mobile navigation
- Scroll-reveal animations and floating hero artwork
- Animated hover states on cards and buttons
- Scroll progress indicator and back-to-top control
- Optional dark mode toggle (preference saved in browser local storage)
- Floating WhatsApp contact link
- Reduced-motion accessibility support
- Gallery lightbox for images marked with `data-lightbox`

## Run locally
1. Extract this folder into `C:\xampp\htdocs\eastern-moro-school-static` (or any static hosting folder).
2. Open `http://localhost/eastern-moro-school-static/` in a browser, or open `index.html` directly.
3. No MySQL setup is needed. Upload the folder to Netlify, GitHub Pages, or another static host to publish it.

## Before publishing
- Replace `assets/images/school-logo.svg` with the school's approved logo while preserving the filename, or update all logo references.
- Add only school-approved photographs to the gallery and write appropriate alt text.
- Confirm the WhatsApp number in `assets/js/app.js` and the WhatsApp links in the HTML files.
- Configure the actual production domain in canonical/SEO metadata when the domain is known.
- The admissions/contact enquiry forms prepare a WhatsApp message; they do not store data or submit to a server.
- Application status is informational only because a static website has no private application records.
- External Google Fonts, Font Awesome CDN, map embed and WhatsApp links need an internet connection.
