(()=>{'use strict';
const body=document.body;
const toggle=document.querySelector('.menu-toggle'),nav=document.querySelector('.main-nav');
if(toggle&&nav){toggle.addEventListener('click',()=>{const open=nav.classList.toggle('open');toggle.setAttribute('aria-expanded',String(open));toggle.setAttribute('aria-label',open?'Close navigation':'Open navigation');toggle.innerHTML=open?'<i class="fa-solid fa-xmark"></i>':'<i class="fa-solid fa-bars"></i>'})}
// Theme preference is stored locally; the site remains fully static.
const themeBtn=document.querySelector('.theme-toggle');
const applyTheme=dark=>{body.classList.toggle('dark-mode',dark);if(themeBtn){themeBtn.innerHTML=dark?'<i class="fa-solid fa-sun"></i>':'<i class="fa-solid fa-moon"></i>';themeBtn.setAttribute('aria-label',dark?'Switch to light mode':'Switch to dark mode');themeBtn.title=dark?'Switch to light mode':'Switch to dark mode'}};
let savedTheme=null;try{savedTheme=localStorage.getItem('eastern-moro-theme')}catch(e){}
applyTheme(savedTheme==='dark');
if(themeBtn)themeBtn.addEventListener('click',()=>{const dark=!body.classList.contains('dark-mode');applyTheme(dark);try{localStorage.setItem('eastern-moro-theme',dark?'dark':'light')}catch(e){}});
// Scroll reveal animations, with reduced-motion support.
const reduceMotion=window.matchMedia('(prefers-reduced-motion: reduce)').matches;
const revealTargets=document.querySelectorAll('.section,.page-hero,.feature-card,.content-card,.step,.form-card,.image-panel,.cta-band,.gallery-item,.split > div,.hero-grid > div');
revealTargets.forEach((el,i)=>{if(!el.classList.contains('fade-up'))el.classList.add('reveal');if(el.matches('.feature-card,.content-card,.step,.gallery-item'))el.style.setProperty('--reveal-delay',`${(i%4)*75}ms`)});
if(!reduceMotion&&'IntersectionObserver'in window){const observer=new IntersectionObserver(entries=>entries.forEach(entry=>{if(entry.isIntersecting){entry.target.classList.add('is-visible');observer.unobserve(entry.target)}}),{threshold:.12,rootMargin:'0px 0px -35px 0px'});document.querySelectorAll('.reveal').forEach(el=>observer.observe(el))}else document.querySelectorAll('.reveal').forEach(el=>el.classList.add('is-visible'));
// Scroll progress and back-to-top control.
const progress=document.querySelector('.scroll-progress span'),topBtn=document.querySelector('.back-to-top');
const onScroll=()=>{const max=document.documentElement.scrollHeight-window.innerHeight;const pct=max>0?window.scrollY/max*100:0;if(progress)progress.style.width=pct+'%';if(topBtn)topBtn.classList.toggle('visible',window.scrollY>450);const header=document.querySelector('.site-header');if(header)header.classList.toggle('is-scrolled',window.scrollY>20)};
window.addEventListener('scroll',onScroll,{passive:true});onScroll();if(topBtn)topBtn.addEventListener('click',()=>window.scrollTo({top:0,behavior:reduceMotion?'auto':'smooth'}));
// Lightbox for approved gallery images.
document.querySelectorAll('[data-lightbox]').forEach(img=>img.addEventListener('click',()=>{const d=document.createElement('dialog');d.className='lightbox-dialog';d.innerHTML='<button aria-label="Close image">×</button><img alt="">';d.querySelector('img').src=img.src;d.querySelector('img').alt=img.alt;document.body.append(d);d.showModal();d.querySelector('button').onclick=()=>d.close();d.addEventListener('click',e=>{if(e.target===d)d.close()});d.addEventListener('close',()=>d.remove())}));
// Static admission/enquiry forms prepare a WhatsApp message; no data is stored.
document.querySelectorAll('[data-wa-form]').forEach(form=>form.addEventListener('submit',e=>{e.preventDefault();if(!form.reportValidity())return;const data=new FormData(form);const lines=[];for(const [k,v] of data.entries())if(String(v).trim())lines.push(k.replaceAll('_',' ')+': '+v);const msg=encodeURIComponent('Eastern Moro Islamic English Medium School — '+form.dataset.waForm+'\n'+lines.join('\n'));window.open('https://wa.me/255710825221?text='+msg,'_blank','noopener');const note=form.querySelector('[data-form-note]');if(note)note.hidden=false}));
document.querySelectorAll('[data-year]').forEach(el=>el.textContent=new Date().getFullYear());
})();
